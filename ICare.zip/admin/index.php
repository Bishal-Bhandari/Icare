<?php
include('includes/header.php');
include('includes/navbar_top.php');
include('includes/menu_bar_side.php');
?>
<section>
    <div class="row">
        <div class="col-12">
            <img src="..img/banner.jpg" alt="Banner" width="100%">
        </div>
    </div>
</section>
<?php
include('includes/footer.php');
?>