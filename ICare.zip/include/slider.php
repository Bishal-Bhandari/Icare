 <!-- Header -->
 <header class="masthead">
    <div class="container">
      <div class="intro-text">
        <div class="intro-heading text-uppercase">Welcome to ICare Technology</div>
        <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger head-btn" href="contact.php" data-aos="fade-up" data-aos-duration="1000">Contact Us for your dream project!!</a>
      </div>
    </div>
  </header>